#!/bin/sh

java gui.MainFrame
